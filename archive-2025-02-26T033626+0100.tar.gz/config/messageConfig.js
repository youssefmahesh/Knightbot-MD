const channelInfo = {
    'contextInfo': {
        'forwardingScore': 999,
        'isForwarded': true,
        'forwardedNewsletterMessageInfo': {
            'newsletterJid': '0029Vb2ZhRF77qVbEkhgqv25@newsletter',
            'newsletterName': 'KnightBot MD',
            'serverMessageId': -1
        }
    }
};

module.exports = { 'channelInfo': channelInfo };
